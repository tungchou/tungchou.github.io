#ifndef OT_CONFIG_H
#define OT_CONFIG_H

#define NOTS 16

#define HASHBYTES 32
#define HASHBITS (HASHBYTES * 8)

#define PACKBYTES 32

#define DIST 1

#define VERBOSE 1

#endif //ifndef OT_CONFIG_H

