#ifndef ENCRYPT_H
#define ENCRYPT_H

void encrypt(unsigned char *, unsigned char *, const unsigned char *);

#endif

