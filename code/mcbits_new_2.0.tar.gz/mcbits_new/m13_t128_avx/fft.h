#include <stdint.h>
#include "params.h"
#include "vec128.h"
#include "vec256.h"

void fft(vec256 [][GFBITS], vec128 *);

