#ifndef FFT_TR_H
#define FFT_TR_H

#include "params.h"
#include "vec256.h"

void fft_tr(vec256 *, vec256 [][ GFBITS ]);

#endif

