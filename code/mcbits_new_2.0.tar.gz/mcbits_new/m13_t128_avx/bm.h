#ifndef BM_H
#define BM_H

#include "vec128.h"
#include "vec256.h"

void bm(vec128 *, vec256 *);

#endif

