#ifndef BENES_H
#define BENES_H

#include "vec128.h"

void benes(vec128 *, vec128 *, int);

#endif

