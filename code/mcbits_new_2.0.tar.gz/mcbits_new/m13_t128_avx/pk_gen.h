#ifndef PK_GEN_H
#define PK_GEN_H

int pk_gen(unsigned char *, const unsigned char *);

#endif

