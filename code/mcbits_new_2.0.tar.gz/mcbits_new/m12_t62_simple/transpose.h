#include <stdint.h>

void transpose_64x64_compact(uint64_t *, uint64_t *);
void transpose_8x64(uint64_t *);

