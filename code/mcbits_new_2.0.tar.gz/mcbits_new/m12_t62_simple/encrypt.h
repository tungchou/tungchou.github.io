void syndrome(unsigned char *, const unsigned char *, const unsigned char *);
void encrypt(unsigned char *, unsigned char *, const unsigned char *);

