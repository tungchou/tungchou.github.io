#include <stdint.h>

void sk_gen(unsigned char *);

