#include "params.h"

#include <stdint.h>

void fft(uint64_t [][ GFBITS ], uint64_t *);

