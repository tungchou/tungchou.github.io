#include "params.h"

#include <stdint.h>

void bm(uint64_t [ GFBITS ], uint64_t [][ GFBITS ]);

