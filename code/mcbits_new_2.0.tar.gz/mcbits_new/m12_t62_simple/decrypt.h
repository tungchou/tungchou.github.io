
int decrypt(unsigned char *, const unsigned char *, const unsigned char *);

