#include <stdint.h>

int pk_gen(unsigned char *, const unsigned char *);
