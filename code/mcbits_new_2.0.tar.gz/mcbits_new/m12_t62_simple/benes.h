#include <stdint.h>

void benes_compact(uint64_t *, uint64_t *, int);

