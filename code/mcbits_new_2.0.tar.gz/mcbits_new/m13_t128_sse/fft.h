#include <stdint.h>
#include "params.h"
#include "vec128.h"

void fft(vec128 [][GFBITS], vec128 *);

