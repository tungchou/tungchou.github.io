#include "params.h"

#include <stdint.h>

void fft_tr(uint64_t [][GFBITS], uint64_t [][ GFBITS ]);

