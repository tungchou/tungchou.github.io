#include <stdint.h>

void pt();
void nl();

void store8(unsigned char *, uint64_t);
uint64_t load8(const unsigned char *);

