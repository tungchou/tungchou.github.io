#include "pk_gen.h"

#include "params.h"
#include "vec128.h"
#include "benes.h"
#include "util.h"
#include "fft.h"
#include "gf.h"

#include <stdint.h>
#include <string.h>

int pk_gen(unsigned char * pk, const unsigned char * sk)
{
	int i, j, k;
	int row, c;

	unsigned char mat[ GFBITS * SYS_T ][ 1024 ];
	uint64_t mask;	

	vec128 irr_int[ GFBITS ];

	u128 consts[64][ GFBITS ] = 
	{
#include "points13.data"
	};

	vec128 buf[ GFBITS ][ 64 ];
	vec128 eval[ 64 ][ GFBITS ];
	vec128 prod[ 64 ][ GFBITS ];
	vec128 tmp[ GFBITS ];

	vec128 b[25][32];

	// compute the inverses 

	irr_load(irr_int, sk);

	fft(eval, irr_int);

	vec128_copy(prod[0], eval[0]);

	for (i = 1; i < 64; i++)
		vec128_mul(prod[i], prod[i-1], eval[i]);

	vec128_inv(tmp, prod[63]);

	for (i = 62; i >= 0; i--)
	{
		vec128_mul(prod[i+1], prod[i], tmp);
		vec128_mul(tmp, tmp, eval[i+1]);
	}

	vec128_copy(prod[0], tmp);

	// fill matrix 

	load_bits(b, sk + IRR_BYTES);

	for (k = 0; k < GFBITS; k++)
	{
		for (j = 0; j < 64; j++) 	
			buf[ k ][ j ] = consts[ j ][ k ].v;

		benes((vec128 *) buf[ k ], b, 0);

		for (j = 0; j < 64; j++) 
			consts[ j ][ k ].v = buf[ k ][ j ];
	}

	for (k = 0; k < GFBITS; k++)
	{
		for (j = 0; j < 64; j++) 
			buf[ k ][ j ] = prod[ j ][ k ];

		benes((vec128 *) buf[ k ], b, 0);

		for (j = 0; j < 64; j++) 
			prod[ j ][ k ] = buf[ k ][ j ];
	}

	for (j = 0; j < 64; j++)
	{
		for (k = 0; k < GFBITS; k++)
			store16(mat[ k ] + j*16, prod[ j ][ k ]);
	}

	for (i = 1; i < SYS_T; i++)
	{
		for (j = 0; j < 64; j++)
		{
			vec128_mul(prod[j], prod[j], (vec128 *) consts[j]);
			
			for (k = 0; k < GFBITS; k++)
				store16(mat[ i*GFBITS + k ] + j*16, prod[ j ][ k ]);
		}
	}

	// gaussian elimination 

	for (i = 0; i < (GFBITS * SYS_T + 7) / 8; i++)
	for (j = 0; j < 8; j++)
	{
		row = i*8 + j;			

		if (row >= GFBITS * SYS_T)
			break;

		for (k = row + 1; k < GFBITS * SYS_T; k++)
		{
			mask = mat[ row ][ i ] ^ mat[ k ][ i ];
			mask >>= j;
			mask &= 1;
			mask = -mask;

			for (c = 0; c < SYS_N/8; c++)
				mat[ row ][ c ] ^= mat[ k ][ c ] & mask;
		}

		if ( ((mat[ row ][ i ] >> j) & 1) == 0 ) // return if not systematic
		{
			return -1;
		}

		for (k = 0; k < GFBITS * SYS_T; k++)
		{
			if (k != row)
			{
				mask = mat[ k ][ i ] >> j;
				mask &= 1;
				mask = -mask;

				for (c = 0; c < SYS_N/8; c++)
					mat[ k ][ c ] ^= mat[ row ][ c ] & mask;
			}
		}
	}
/*
	for (i = 0; i < (GFBITS * SYS_T + 7) / 8; i++)
	for (j = 0; j < 8; j++)
	{
		row = i*8 + j;			

		for (k = 0; k < row; k++)
		{
			mask = mat[ k ][ i ] >> j;
			mask &= 1;
			mask = -mask;

			for (c = i; c < SYS_N/8; c++)
				mat[ k ][ c ] ^= mat[ row ][ c ] & mask;
		}
	}
*/
	for (i = 0; i < PK_NROWS; i++)
		memcpy(pk + i*PK_ROW_BYTES, mat[i] + PK_NROWS/8, PK_ROW_BYTES);

	return 0;
}

