make vec128_mul_asm.s
make update_asm.s
make vec_reduce_asm.s
make syndrome_asm.s
make transpose_64x128_sp_asm.s 
