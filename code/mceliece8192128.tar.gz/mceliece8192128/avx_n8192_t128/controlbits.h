#ifndef CONTROLBITS_H
#define CONTROLBITS_H

#include <stdint.h>

void controlbits(unsigned char * out);

#endif

