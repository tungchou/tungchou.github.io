make vec128_mul_asm.s
make vec256_mul_asm.s
make vec256_ama_asm.s
make vec256_maa_asm.s
make update_asm.s
make vec_reduce_asm.s
make syndrome_asm.s
make transpose_64x128_sp_asm.s 

