#ifndef LADDER_H
#define LADDER_H

#include "fe.h"
#include "ladder_namespace.h"

extern void ladder(fe *, const unsigned char *);

#endif //ifndef LADDER_H

